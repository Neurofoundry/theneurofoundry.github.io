"""Stateful scenario engine for Mirage API Lab."""
from __future__ import annotations

import copy
import json
import re
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any


class BlueprintError(ValueError):
    pass


TOKEN = re.compile(r"\{\{\s*(path|request|vars|state)\.([A-Za-z0-9_.-]+)\s*\}\}")


def load_blueprint(path: str | Path) -> dict:
    try:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise BlueprintError(f"Could not read blueprint: {exc}") from exc
    validate_blueprint(data)
    return data


def validate_blueprint(data: Any) -> None:
    if not isinstance(data, dict):
        raise BlueprintError("Blueprint root must be an object")
    if not isinstance(data.get("name"), str) or not data["name"].strip():
        raise BlueprintError("name must be a non-empty string")
    scenarios = data.get("scenarios")
    if not isinstance(scenarios, dict) or not scenarios:
        raise BlueprintError("scenarios must be a non-empty object")
    for scenario_name, scenario in scenarios.items():
        if not isinstance(scenario, dict):
            raise BlueprintError(f"scenario {scenario_name} must be an object")
        phases = scenario.get("phases")
        initial = scenario.get("initial_phase")
        if not isinstance(phases, dict) or not phases or initial not in phases:
            raise BlueprintError(f"scenario {scenario_name} needs phases and a valid initial_phase")
        seen = set()
        for phase_name, phase in phases.items():
            routes = phase.get("routes", []) if isinstance(phase, dict) else None
            if not isinstance(routes, list):
                raise BlueprintError(f"{scenario_name}.{phase_name}.routes must be a list")
            for i, route in enumerate(routes):
                if not isinstance(route, dict):
                    raise BlueprintError(f"route {scenario_name}.{phase_name}[{i}] must be an object")
                for key in ("id", "method", "path", "response"):
                    if key not in route:
                        raise BlueprintError(f"route {scenario_name}.{phase_name}[{i}] missing {key}")
                if route["id"] in seen:
                    raise BlueprintError(f"duplicate route id in scenario {scenario_name}: {route['id']}")
                seen.add(route["id"])
                if route.get("next_phase") not in (None, *phases.keys()):
                    raise BlueprintError(f"route {route['id']} has unknown next_phase")
                response = route["response"]
                if not isinstance(response, dict) or not isinstance(response.get("status", 200), int):
                    raise BlueprintError(f"route {route['id']} response must be an object with integer status")
                if int(route.get("latency_ms", 0)) < 0:
                    raise BlueprintError(f"route {route['id']} latency_ms cannot be negative")


def _lookup(source: Any, dotted: str) -> Any:
    value = source
    for part in dotted.split("."):
        if isinstance(value, dict) and part in value:
            value = value[part]
        else:
            return ""
    return value


def render(value: Any, context: dict) -> Any:
    if isinstance(value, dict):
        return {key: render(item, context) for key, item in value.items()}
    if isinstance(value, list):
        return [render(item, context) for item in value]
    if not isinstance(value, str):
        return value
    match = TOKEN.fullmatch(value)
    if match:
        return copy.deepcopy(_lookup(context.get(match.group(1), {}), match.group(2)))
    return TOKEN.sub(lambda m: str(_lookup(context.get(m.group(1), {}), m.group(2))), value)


def compile_path(pattern: str) -> re.Pattern:
    chunks = []
    cursor = 0
    for match in re.finditer(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", pattern):
        chunks.append(re.escape(pattern[cursor:match.start()]))
        chunks.append(f"(?P<{match.group(1)}>[^/]+)")
        cursor = match.end()
    chunks.append(re.escape(pattern[cursor:]))
    return re.compile("^" + "".join(chunks) + "$" )


def _subset(expected: Any, actual: Any) -> bool:
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(key in actual and _subset(value, actual[key]) for key, value in expected.items())
    if isinstance(expected, list):
        return isinstance(actual, list) and len(expected) == len(actual) and all(_subset(a, b) for a, b in zip(expected, actual))
    return expected == actual


def redact(value: Any, keys: set[str]) -> Any:
    if isinstance(value, dict):
        return {key: ("[REDACTED]" if key.lower() in keys else redact(item, keys)) for key, item in value.items()}
    if isinstance(value, list):
        return [redact(item, keys) for item in value]
    return value


@dataclass
class Result:
    status: int
    headers: dict[str, str]
    body: Any
    delay_ms: int = 0


class MirageEngine:
    def __init__(self, blueprint: dict, scenario: str | None = None):
        validate_blueprint(blueprint)
        self.blueprint = copy.deepcopy(blueprint)
        self.lock = threading.RLock()
        self.redact_keys = {str(x).lower() for x in blueprint.get("redact_keys", ["authorization", "token", "password", "secret", "api_key"])}
        self.journal: list[dict] = []
        self.sequence = 0
        self.fault: dict | None = None
        self.select_scenario(scenario or next(iter(blueprint["scenarios"])))

    def select_scenario(self, name: str) -> None:
        if name not in self.blueprint["scenarios"]:
            raise BlueprintError(f"Unknown scenario: {name}")
        with self.lock:
            self.scenario_name = name
            self.scenario = self.blueprint["scenarios"][name]
            self.phase = self.scenario["initial_phase"]
            self.variables = copy.deepcopy(self.scenario.get("variables", {}))
            self.journal = []
            self.sequence = 0
            self.fault = None

    def reset(self) -> None:
        self.select_scenario(self.scenario_name)

    def arm_fault(self, status: int = 503, body: Any = None, latency_ms: int = 0) -> None:
        if not 400 <= status <= 599 or latency_ms < 0:
            raise BlueprintError("fault status must be 400-599 and latency_ms non-negative")
        with self.lock:
            self.fault = {"status": status, "body": body if body is not None else {"error": "armed_fault"}, "latency_ms": latency_ms}

    def status(self) -> dict:
        with self.lock:
            return {"name": self.blueprint["name"], "scenario": self.scenario_name, "phase": self.phase,
                    "variables": redact(copy.deepcopy(self.variables), self.redact_keys), "journal_entries": len(self.journal),
                    "fault_armed": self.fault is not None, "available_scenarios": sorted(self.blueprint["scenarios"])}

    def handle(self, method: str, path: str, body: Any = None, headers: dict | None = None) -> Result:
        started = time.time()
        headers = headers or {}
        method = method.upper()
        with self.lock:
            phase_before = self.phase
            if self.fault:
                fault = self.fault
                self.fault = None
                result = Result(fault["status"], {"Content-Type": "application/json", "X-Mirage-Fault": "armed"}, fault["body"], fault["latency_ms"])
                self._record(method, path, body, headers, phase_before, self.phase, "__armed_fault__", result, started)
                return result
            routes = self.scenario["phases"][self.phase].get("routes", [])
            for route in routes:
                match = compile_path(route["path"]).match(path)
                if route["method"].upper() != method or not match or not _subset(route.get("match_body", {}), body or {}):
                    continue
                context = {"path": match.groupdict(), "request": body or {}, "vars": self.variables, "state": {"phase": self.phase, "scenario": self.scenario_name}}
                for key, value in route.get("set", {}).items():
                    self.variables[key] = render(value, context)
                response = route["response"]
                result = Result(int(response.get("status", 200)), {"Content-Type": "application/json", **response.get("headers", {})}, render(response.get("body"), context), int(route.get("latency_ms", 0)))
                if route.get("next_phase"):
                    self.phase = route["next_phase"]
                self._record(method, path, body, headers, phase_before, self.phase, route["id"], result, started)
                return result
            result = Result(404, {"Content-Type": "application/json"}, {"error": "no_route", "scenario": self.scenario_name, "phase": self.phase, "method": method, "path": path})
            self._record(method, path, body, headers, phase_before, self.phase, None, result, started)
            return result

    def _record(self, method: str, path: str, body: Any, headers: dict, before: str, after: str, route: str | None, result: Result, started: float) -> None:
        self.sequence += 1
        self.journal.append({"sequence": self.sequence, "id": str(uuid.uuid4()), "timestamp": round(started, 3),
            "request": redact({"method": method, "path": path, "headers": headers, "body": body}, self.redact_keys),
            "route_id": route, "phase_before": before, "phase_after": after,
            "response": {"status": result.status, "body": redact(copy.deepcopy(result.body), self.redact_keys)}, "delay_ms": result.delay_ms})

    def export_journal(self) -> dict:
        with self.lock:
            return {"format": "mirage-journal-v1", "blueprint": self.blueprint["name"], "scenario": self.scenario_name, "entries": copy.deepcopy(self.journal)}

    def replay(self, journal: dict) -> list[dict]:
        if journal.get("format") != "mirage-journal-v1":
            raise BlueprintError("Unsupported journal format")
        self.select_scenario(journal["scenario"])
        differences = []
        for expected in journal.get("entries", []):
            if expected.get("route_id") == "__armed_fault__":
                continue
            request = expected["request"]
            result = self.handle(request["method"], request["path"], request.get("body"), request.get("headers"))
            actual = {"status": result.status, "body": redact(copy.deepcopy(result.body), self.redact_keys)}
            if actual != expected["response"]:
                differences.append({"sequence": expected["sequence"], "expected": expected["response"], "actual": actual})
        return differences
