import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from mirage_core import BlueprintError, MirageEngine, load_blueprint, redact, render, validate_blueprint

ROOT = Path(__file__).parent


class MirageTests(unittest.TestCase):
    def setUp(self):
        self.blueprint = load_blueprint(ROOT / "example-blueprint.json")
        self.engine = MirageEngine(self.blueprint, "successful_delivery")

    def test_full_stateful_delivery_lifecycle(self):
        created = self.engine.handle("POST", "/v1/shipments", {"service": "express", "order_id": "A42"})
        self.assertEqual(201, created.status)
        self.assertEqual("trk-A42", created.body["tracking_id"])
        self.assertEqual("in_transit", self.engine.phase)
        transit = self.engine.handle("GET", "/v1/shipments/trk-A42")
        self.assertEqual("in_transit", transit.body["status"])
        self.engine.handle("POST", "/v1/sandbox/advance")
        delivered = self.engine.handle("GET", "/v1/shipments/trk-A42")
        self.assertEqual("delivered", delivered.body["status"])
        self.assertEqual(["create_shipment", "track_in_transit", "advance_delivery", "track_delivered"], [x["route_id"] for x in self.engine.journal])

    def test_scenario_switch_and_body_match(self):
        miss = self.engine.handle("POST", "/v1/shipments", {"service": "economy", "order_id": "A1"})
        self.assertEqual(404, miss.status)
        self.engine.select_scenario("address_rejected")
        rejected = self.engine.handle("POST", "/v1/shipments", {"service": "express"})
        self.assertEqual(422, rejected.status)

    def test_fault_is_one_shot_and_journaled(self):
        self.engine.arm_fault(429, {"error": "rate_limited"}, 5)
        first = self.engine.handle("GET", "/anything")
        second = self.engine.handle("GET", "/anything")
        self.assertEqual(429, first.status)
        self.assertEqual(404, second.status)
        self.assertEqual("__armed_fault__", self.engine.journal[0]["route_id"])

    def test_sensitive_keys_are_redacted_recursively(self):
        self.engine.handle("GET", "/unknown", {"nested": {"token": "nope"}}, {"Authorization": "secret"})
        entry = self.engine.export_journal()["entries"][0]
        self.assertEqual("[REDACTED]", entry["request"]["headers"]["Authorization"])
        self.assertEqual("[REDACTED]", entry["request"]["body"]["nested"]["token"])

    def test_exported_journal_replays_without_differences(self):
        self.engine.handle("POST", "/v1/shipments", {"service": "express", "order_id": "A42"})
        self.engine.handle("GET", "/v1/shipments/trk-A42")
        journal = self.engine.export_journal()
        replay_engine = MirageEngine(self.blueprint)
        self.assertEqual([], replay_engine.replay(journal))

    def test_validation_rejects_unknown_phase(self):
        broken = json.loads(json.dumps(self.blueprint))
        broken["scenarios"]["successful_delivery"]["phases"]["ready"]["routes"][0]["next_phase"] = "missing"
        with self.assertRaises(BlueprintError):
            validate_blueprint(broken)

    def test_template_preserves_typed_full_value(self):
        rendered = render({"copied": "{{request.payload}}", "label": "ID={{path.id}}"}, {"request": {"payload": {"x": 2}}, "path": {"id": "7"}})
        self.assertEqual({"x": 2}, rendered["copied"])
        self.assertEqual("ID=7", rendered["label"])

    def test_cli_verify(self):
        result = subprocess.run([sys.executable, str(ROOT / "mirage.py"), "verify", str(ROOT / "example-blueprint.json")], capture_output=True, text=True)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn("VALID", result.stdout)


if __name__ == "__main__":
    unittest.main()
