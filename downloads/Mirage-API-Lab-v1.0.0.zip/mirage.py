#!/usr/bin/env python3
"""Mirage API Lab: stateful local dependency simulation."""
from __future__ import annotations

import argparse
import json
import sys
import time
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from mirage_core import BlueprintError, MirageEngine, load_blueprint


DASHBOARD = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Mirage API Lab</title><style>
:root{color-scheme:dark;--bg:#090d14;--panel:#121925;--line:#273247;--ink:#edf3ff;--muted:#93a0b8;--hot:#ff6243;--good:#41d68c}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 80% 0,#17233a,#090d14 45%);color:var(--ink);font:14px/1.5 system-ui}main{max-width:1100px;margin:auto;padding:36px 22px}h1{font-size:2.5rem;margin:.1em 0}.brand{color:var(--hot);letter-spacing:.15em;text-transform:uppercase}.grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:24px 0}.card,.panel{background:rgba(18,25,37,.94);border:1px solid var(--line);border-radius:12px;padding:18px}.card b{font-size:1.4rem;display:block}.card span,.muted{color:var(--muted)}.split{display:grid;grid-template-columns:1fr 1.5fr;gap:16px}button,select,input{background:#1b2535;color:var(--ink);border:1px solid #394963;border-radius:7px;padding:9px;margin:3px}button:hover{border-color:var(--hot)}table{width:100%;border-collapse:collapse}td,th{padding:8px;border-bottom:1px solid var(--line);text-align:left}code{color:#a9c7ff}.ok{color:var(--good)}@media(max-width:750px){.grid{grid-template-columns:1fr 1fr}.split{grid-template-columns:1fr}}</style></head>
<body><main><div class="brand">Neurofoundry / Local Integration Rehearsal</div><h1>Mirage API Lab</h1><p class="muted">Drive the dependency. Change the scene. Keep the evidence.</p><div class="grid"><div class="card"><b id="name">—</b><span>blueprint</span></div><div class="card"><b id="scenario">—</b><span>scenario</span></div><div class="card"><b id="phase">—</b><span>phase</span></div><div class="card"><b id="count">0</b><span>interactions</span></div></div><div class="split"><section class="panel"><h2>Controls</h2><label>Scenario <select id="scenarios"></select></label><button onclick="choose()">Load</button><button onclick="resetLab()">Reset</button><h3>One-shot fault</h3><input id="faultStatus" type="number" value="503" min="400" max="599"><input id="faultDelay" type="number" value="0" min="0"><button onclick="fault()">Arm next request</button><p id="message" class="ok"></p><h3>Variables</h3><pre id="vars"></pre></section><section class="panel"><h2>Live journal</h2><table><thead><tr><th>#</th><th>Request</th><th>Route</th><th>Phase</th><th>Status</th></tr></thead><tbody id="journal"></tbody></table></section></div></main><script>
const $=id=>document.getElementById(id),api=async(p,o={})=>{const r=await fetch(p,{headers:{'Content-Type':'application/json'},...o});return r.json()};async function refresh(){const s=await api('/_mirage/status'),j=await api('/_mirage/journal');$('name').textContent=s.name;$('scenario').textContent=s.scenario;$('phase').textContent=s.phase;$('count').textContent=s.journal_entries;$('vars').textContent=JSON.stringify(s.variables,null,2);const picker=$('scenarios'),selected=picker.value;picker.innerHTML=s.available_scenarios.map(x=>`<option>${x}</option>`).join('');picker.value=s.available_scenarios.includes(selected)?selected:s.scenario;$('journal').innerHTML=j.entries.slice().reverse().map(x=>`<tr><td>${x.sequence}</td><td><code>${x.request.method} ${esc(x.request.path)}</code></td><td>${esc(x.route_id||'unmatched')}</td><td>${esc(x.phase_before)} → ${esc(x.phase_after)}</td><td>${x.response.status}</td></tr>`).join('')}const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));async function choose(){await api('/_mirage/scenario',{method:'POST',body:JSON.stringify({name:$('scenarios').value})});$('message').textContent='Scenario loaded';refresh()}async function resetLab(){await api('/_mirage/reset',{method:'POST',body:'{}'});$('message').textContent='Simulator reset';refresh()}async function fault(){await api('/_mirage/fault',{method:'POST',body:JSON.stringify({status:+$('faultStatus').value,latency_ms:+$('faultDelay').value})});$('message').textContent='Fault armed for the next API request';refresh()}refresh();setInterval(refresh,1500)</script></body></html>'''


def make_handler(engine: MirageEngine):
    class Handler(BaseHTTPRequestHandler):
        server_version = "MirageAPI/1.0"

        def log_message(self, fmt, *args):
            print(f"[{self.log_date_time_string()}] {fmt % args}")

        def _json_body(self):
            length = int(self.headers.get("Content-Length", "0"))
            if not length:
                return None
            try:
                return json.loads(self.rfile.read(length))
            except json.JSONDecodeError:
                raise BlueprintError("Request body must be valid JSON")

        def _send(self, status, body, headers=None):
            payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            for key, value in (headers or {}).items():
                self.send_header(key, str(value))
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(payload)))
            self.end_headers()
            self.wfile.write(payload)

        def _control(self, method, path, body):
            if method == "GET" and path == "/_mirage/status": return 200, engine.status()
            if method == "GET" and path == "/_mirage/journal": return 200, engine.export_journal()
            if method == "POST" and path == "/_mirage/reset": engine.reset(); return 200, engine.status()
            if method == "POST" and path == "/_mirage/scenario": engine.select_scenario((body or {}).get("name", "")); return 200, engine.status()
            if method == "POST" and path == "/_mirage/fault":
                body = body or {}; engine.arm_fault(int(body.get("status", 503)), body.get("body"), int(body.get("latency_ms", 0))); return 200, engine.status()
            return None

        def _handle(self):
            path = urllib.parse.urlsplit(self.path).path
            if self.command == "GET" and path == "/favicon.ico":
                self.send_response(204); self.end_headers(); return
            if self.command == "GET" and path in ("/", "/_mirage"):
                data = DASHBOARD.encode("utf-8"); self.send_response(200); self.send_header("Content-Type", "text/html; charset=utf-8"); self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data); return
            try:
                body = self._json_body()
                control = self._control(self.command, path, body)
                if control:
                    self._send(*control); return
                headers = {key: value for key, value in self.headers.items()}
                result = engine.handle(self.command, path, body, headers)
                if result.delay_ms: time.sleep(result.delay_ms / 1000)
                self._send(result.status, result.body, result.headers)
            except BlueprintError as exc:
                self._send(400, {"error": str(exc)})
            except (BrokenPipeError, ConnectionResetError):
                pass

        do_GET = do_POST = do_PUT = do_PATCH = do_DELETE = _handle
    return Handler


def main(argv=None):
    parser = argparse.ArgumentParser(description="Run and verify stateful local API doubles")
    sub = parser.add_subparsers(dest="command", required=True)
    serve = sub.add_parser("serve", help="start the simulator and dashboard")
    serve.add_argument("blueprint"); serve.add_argument("--scenario"); serve.add_argument("--host", default="127.0.0.1"); serve.add_argument("--port", type=int, default=8787)
    verify = sub.add_parser("verify", help="validate a blueprint")
    verify.add_argument("blueprint")
    replay = sub.add_parser("replay", help="replay an exported journal against its scenario")
    replay.add_argument("blueprint"); replay.add_argument("journal")
    args = parser.parse_args(argv)
    try:
        blueprint = load_blueprint(args.blueprint)
        if args.command == "verify": print(f"VALID: {blueprint['name']} ({len(blueprint['scenarios'])} scenario(s))"); return 0
        engine = MirageEngine(blueprint, getattr(args, "scenario", None))
        if args.command == "replay":
            journal = json.loads(Path(args.journal).read_text(encoding="utf-8")); differences = engine.replay(journal)
            print(json.dumps({"passed": not differences, "differences": differences}, indent=2)); return 0 if not differences else 2
        server = ThreadingHTTPServer((args.host, args.port), make_handler(engine))
        print(f"Mirage API Lab: http://{args.host}:{server.server_port}/  scenario={engine.scenario_name}")
        try: server.serve_forever()
        except KeyboardInterrupt: pass
        finally: server.server_close()
        return 0
    except (BlueprintError, OSError, json.JSONDecodeError) as exc:
        print(f"mirage: {exc}", file=sys.stderr); return 2


if __name__ == "__main__":
    raise SystemExit(main())
