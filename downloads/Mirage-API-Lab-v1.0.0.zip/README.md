# Mirage API Lab

Mirage API Lab is a stateful local stand-in for third-party APIs. It lets you rehearse an integration today—even when the real provider is unavailable, expensive, rate-limited, or unable to reproduce the lifecycle you need.

Unlike a static mock, Mirage changes phase as requests arrive. A shipment can move from creation to transit to delivery; an identity check can move from pending to approved; a payment can be authorized, captured, disputed, and refunded. Responses can use path values, request fields, and remembered variables. You can switch scenarios, arm a one-shot failure, inspect every interaction, export redacted evidence, reset instantly, and replay an observed contract deterministically.

## Requirements

- Python 3.10 or newer
- No third-party packages
- A modern browser for the operator dashboard

## First run

```powershell
python mirage.py verify example-blueprint.json
python mirage.py serve example-blueprint.json --port 8787
```

Open `http://127.0.0.1:8787/` for the dashboard. In another terminal, drive the included parcel lifecycle:

```powershell
curl.exe -X POST http://127.0.0.1:8787/v1/shipments -H "Content-Type: application/json" -d '{"service":"express","order_id":"A42"}'
curl.exe http://127.0.0.1:8787/v1/shipments/trk-A42
curl.exe -X POST http://127.0.0.1:8787/v1/sandbox/advance
curl.exe http://127.0.0.1:8787/v1/shipments/trk-A42
curl.exe http://127.0.0.1:8787/_mirage/journal -o journal.json
```

Stop the server with Ctrl+C, then prove the captured interaction sequence still matches the blueprint:

```powershell
python mirage.py replay example-blueprint.json journal.json
```

The replay exits `0` when every non-fault interaction returns the same status and redacted body, or `2` with exact differences.

## Blueprint model

A blueprint contains named scenarios. Each scenario begins in one phase and provides routes available during that phase.

```json
{
  "name": "Minimal payment partner",
  "scenarios": {
    "happy_path": {
      "initial_phase": "open",
      "variables": {"currency": "USD"},
      "phases": {
        "open": {"routes": [{
          "id": "authorize",
          "method": "POST",
          "path": "/payments/{id}",
          "match_body": {"action": "authorize"},
          "set": {"last_id": "{{path.id}}"},
          "next_phase": "authorized",
          "response": {"status": 200, "body": {"id": "{{path.id}}", "amount": "{{request.amount}}", "currency": "{{vars.currency}}"}}
        }]},
        "authorized": {"routes": []}
      }
    }
  }
}
```

Template sources are `path`, `request`, `vars`, and `state`. A template that occupies the whole string preserves the original JSON type. `match_body` performs a recursive subset match. `set` remembers values. `next_phase` changes which routes are active. `latency_ms` adds a deterministic delay.

## Operator API

- `GET /_mirage/status` — active scenario, phase, variables, and counts.
- `GET /_mirage/journal` — redacted portable evidence.
- `POST /_mirage/reset` — clear state and return to the initial phase.
- `POST /_mirage/scenario` with `{"name":"..."}` — switch and reset.
- `POST /_mirage/fault` with `{"status":503,"latency_ms":250,"body":{"error":"maintenance"}}` — fail only the next non-control request.

The dashboard exposes scenario switching, reset, fault arming, current variables, and the live journal without internet access.

## Safety and boundaries

Mirage binds to `127.0.0.1` by default. It never calls an upstream service. Journal keys matching `authorization`, `token`, `password`, `secret`, or `api_key` are redacted recursively; customize `redact_keys` in the blueprint. Do not bind to a public interface with sensitive test data. Mirage simulates JSON HTTP dependencies; it is not a production gateway, TLS terminator, load tester, or security boundary.

## Troubleshooting

- **404 `no_route`:** the method/path/body did not match a route in the current phase; check `/_mirage/status`.
- **422/400 from your simulated API:** that response may be intentionally declared in the blueprint.
- **Port already in use:** choose another with `--port 8790`.
- **Replay differs:** the blueprint changed, the scenario is nondeterministic, or the journal came from another blueprint revision.
- **Blueprint rejected:** run `python mirage.py verify your-blueprint.json` for the exact structural error.

Run the product suite with `python -m unittest -v test_mirage.py`.
