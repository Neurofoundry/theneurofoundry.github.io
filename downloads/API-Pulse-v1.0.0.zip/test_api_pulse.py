import json
import os
import tempfile
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from api_pulse import WorkflowError, json_path, render, run_workflow


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length))
        payload = json.dumps({**body, "id": 42}).encode()
        self.send_response(201)
        self.send_header("Content-Type", "application/json")
        self.send_header("X-Flow", "created")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        payload = json.dumps({"id": 42, "state": "ready"}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        pass


class ApiPulseTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_chained_workflow_and_reports(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            workflow = root / "workflow.json"
            workflow.write_text(json.dumps({"name": "Local chain", "steps": [
                {"id": "create", "method": "POST", "url": f"http://127.0.0.1:{self.server.server_port}/items", "body": {"name": "demo"}, "expect": {"status": 201, "json_equals": {"id": 42}}},
                {"id": "check", "url": f"http://127.0.0.1:{self.server.server_port}/items/${{{{ steps.create.json.id }}}}", "expect": {"status": 200, "json_equals": {"state": "ready"}}}
            ]}), encoding="utf-8")
            output = root / "output"
            self.assertEqual(run_workflow(workflow, output, 2), 0)
            self.assertTrue((output / "api-pulse-report.md").exists())
            self.assertTrue(json.loads((output / "api-pulse-report.json").read_text())["passed"])

    def test_environment_and_json_paths(self):
        os.environ["API_PULSE_TEST"] = "ready"
        self.assertEqual(render("state=${{ env.API_PULSE_TEST }}", {}), "state=ready")
        self.assertEqual(json_path({"items": [{"id": 9}]}, "items.0.id"), 9)
        with self.assertRaises(WorkflowError):
            json_path({}, "missing")


if __name__ == "__main__":
    unittest.main()
