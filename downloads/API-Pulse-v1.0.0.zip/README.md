# API Pulse

API Pulse is a dependency-free Python workflow runner for API smoke tests, deployment verification, integration checks, and repeatable operational proofs. Define requests and assertions in JSON, pass response data between steps, and receive Markdown and JSON evidence reports.

## Requirements

- Python 3.10 or later
- No third-party packages

## Run it today

```powershell
python api_pulse.py example-workflow.json --output .\report
```

Exit codes are `0` for a fully passing workflow, `1` for a failed or incomplete workflow, and `2` for invalid input.

## Workflow features

- GET, POST, PUT, PATCH, DELETE, and other HTTP methods
- JSON or text request bodies
- Status, body-text, JSON-path, and response-header assertions
- `${{ env.NAME }}` environment-variable substitution
- `${{ steps.step-id.json.path.to.value }}` response chaining
- `${{ steps.step-id.header.Header-Name }}` header chaining
- Stop-on-failure by default, with optional `continue_on_failure`
- Automatic redaction of authorization, API-key, and cookie response headers
- Portable Markdown and JSON reports

## Credentials

Keep secrets out of workflow files. Reference environment variables instead:

```json
{
  "headers": {
    "Authorization": "Bearer ${{ env.MY_API_TOKEN }}"
  }
}
```

API Pulse does not print request headers in its reports.

## Assertions

```json
{
  "expect": {
    "status": 200,
    "body_contains": ["ready", "healthy"],
    "json_equals": {"service.state": "ready"},
    "header_equals": {"Content-Type": "application/json"}
  }
}
```

JSON paths support object keys and numeric list indexes, such as `items.0.id`.

## Test locally

```powershell
$env:PYTHONDONTWRITEBYTECODE='1'
python -m unittest discover -s tests -v
```

The tests use a temporary local HTTP server and do not call external services.
