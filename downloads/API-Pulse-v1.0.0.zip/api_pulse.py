#!/usr/bin/env python3
"""Run reusable JSON API workflows and produce portable evidence reports."""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

TOKEN = re.compile(r"\$\{\{\s*(env\.[A-Za-z_][A-Za-z0-9_]*|steps\.[A-Za-z0-9_-]+\.(?:json|header)\.[^}]+)\s*}}")


class WorkflowError(Exception):
    pass


@dataclass
class StepResult:
    id: str
    name: str
    method: str
    url: str
    status: int | None
    duration_ms: int
    passed: bool
    checks: list[str]
    error: str | None
    response_headers: dict[str, str]
    response_json: Any
    response_text: str


def json_path(value: Any, path: str) -> Any:
    current = value
    for part in path.split("."):
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError) as exc:
                raise WorkflowError(f"Invalid list path segment: {part}") from exc
        elif isinstance(current, dict) and part in current:
            current = current[part]
        else:
            raise WorkflowError(f"JSON path not found: {path}")
    return current


def resolve_token(token: str, results: dict[str, StepResult]) -> Any:
    token = token.strip()
    if token.startswith("env."):
        name = token[4:]
        if name not in os.environ:
            raise WorkflowError(f"Missing environment variable: {name}")
        return os.environ[name]
    _, step_id, source, path = token.split(".", 3)
    path = path.strip()
    if step_id not in results:
        raise WorkflowError(f"Step result is not available: {step_id}")
    result = results[step_id]
    if source == "json":
        return json_path(result.response_json, path)
    header = next((value for key, value in result.response_headers.items() if key.lower() == path.lower()), None)
    if header is None:
        raise WorkflowError(f"Header not found on step {step_id}: {path}")
    return header


def render(value: Any, results: dict[str, StepResult]) -> Any:
    if isinstance(value, dict):
        return {key: render(item, results) for key, item in value.items()}
    if isinstance(value, list):
        return [render(item, results) for item in value]
    if not isinstance(value, str):
        return value
    full = TOKEN.fullmatch(value)
    if full:
        return resolve_token(full.group(1), results)
    return TOKEN.sub(lambda match: str(resolve_token(match.group(1), results)), value)


def redact_headers(headers: dict[str, str]) -> dict[str, str]:
    sensitive = {"authorization", "proxy-authorization", "x-api-key", "cookie", "set-cookie"}
    return {key: "[REDACTED]" if key.lower() in sensitive else value for key, value in headers.items()}


def check_response(expect: dict[str, Any], status: int, headers: dict[str, str], body: str, parsed: Any) -> tuple[bool, list[str]]:
    checks = []
    passed = True
    if "status" in expect:
        ok = status == int(expect["status"])
        checks.append(f"status == {expect['status']}: {'PASS' if ok else 'FAIL'} (actual {status})")
        passed &= ok
    if "body_contains" in expect:
        values = expect["body_contains"] if isinstance(expect["body_contains"], list) else [expect["body_contains"]]
        for value in values:
            ok = str(value) in body
            checks.append(f"body contains {value!r}: {'PASS' if ok else 'FAIL'}")
            passed &= ok
    for path, expected in expect.get("json_equals", {}).items():
        try:
            actual = json_path(parsed, path)
            ok = actual == expected
            checks.append(f"json {path} == {expected!r}: {'PASS' if ok else 'FAIL'} (actual {actual!r})")
        except WorkflowError as exc:
            ok = False
            checks.append(f"json {path}: FAIL ({exc})")
        passed &= ok
    for name, expected in expect.get("header_equals", {}).items():
        actual = next((value for key, value in headers.items() if key.lower() == name.lower()), None)
        ok = actual == expected
        checks.append(f"header {name} == {expected!r}: {'PASS' if ok else 'FAIL'} (actual {actual!r})")
        passed &= ok
    return bool(passed), checks


def run_step(step: dict[str, Any], results: dict[str, StepResult], timeout: float) -> StepResult:
    step_id = step["id"]
    name = step.get("name", step_id)
    method = step.get("method", "GET").upper()
    url = str(render(step["url"], results))
    headers = {str(key): str(value) for key, value in render(step.get("headers", {}), results).items()}
    body_value = render(step.get("body"), results)
    data = None
    if body_value is not None:
        if isinstance(body_value, (dict, list)):
            data = json.dumps(body_value).encode("utf-8")
            headers.setdefault("Content-Type", "application/json")
        else:
            data = str(body_value).encode("utf-8")
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    started = time.perf_counter()
    status = None
    response_headers: dict[str, str] = {}
    response_text = ""
    error = None
    try:
        try:
            response = urllib.request.urlopen(request, timeout=timeout)
        except urllib.error.HTTPError as exc:
            response = exc
        with response:
            status = response.status
            response_headers = dict(response.headers.items())
            response_text = response.read().decode("utf-8", errors="replace")
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        error = str(exc)
    duration_ms = round((time.perf_counter() - started) * 1000)
    try:
        response_json = json.loads(response_text) if response_text else None
    except json.JSONDecodeError:
        response_json = None
    if error:
        passed, checks = False, [f"request completed: FAIL ({error})"]
    else:
        passed, checks = check_response(render(step.get("expect", {}), results), status, response_headers, response_text, response_json)
    return StepResult(step_id, name, method, url, status, duration_ms, passed, checks, error, redact_headers(response_headers), response_json, response_text[:4000])


def validate_workflow(workflow: dict[str, Any]) -> None:
    if not isinstance(workflow.get("steps"), list) or not workflow["steps"]:
        raise WorkflowError("Workflow must contain at least one step")
    ids = []
    for index, step in enumerate(workflow["steps"], 1):
        if not isinstance(step, dict) or not step.get("id") or not step.get("url"):
            raise WorkflowError(f"Step {index} requires id and url")
        if not re.fullmatch(r"[A-Za-z0-9_-]+", step["id"]):
            raise WorkflowError(f"Invalid step id: {step['id']}")
        ids.append(step["id"])
    if len(ids) != len(set(ids)):
        raise WorkflowError("Step ids must be unique")


def markdown_report(workflow: dict[str, Any], results: list[StepResult], started: str) -> str:
    passed = sum(result.passed for result in results)
    lines = [
        f"# API Pulse — {workflow.get('name', 'Workflow Report')}", "",
        f"- Started: {started}",
        f"- Result: {'PASS' if passed == len(results) else 'FAIL'}",
        f"- Steps: {passed}/{len(results)} passed", "",
    ]
    for result in results:
        lines.extend([
            f"## {'PASS' if result.passed else 'FAIL'} — {result.name}", "",
            f"`{result.method} {result.url}`", "",
            f"Status: {result.status if result.status is not None else 'No response'}  ",
            f"Duration: {result.duration_ms} ms", "",
            *[f"- {check}" for check in result.checks], "",
        ])
    return "\n".join(lines)


def run_workflow(path: Path, output: Path, timeout: float) -> int:
    try:
        workflow = json.loads(path.read_text(encoding="utf-8"))
        validate_workflow(workflow)
    except (OSError, json.JSONDecodeError, WorkflowError) as exc:
        raise WorkflowError(f"Cannot load workflow: {exc}") from exc
    started = datetime.now(timezone.utc).isoformat()
    by_id: dict[str, StepResult] = {}
    ordered = []
    for step in workflow["steps"]:
        if ordered and not ordered[-1].passed and not workflow.get("continue_on_failure", False):
            break
        result = run_step(step, by_id, timeout)
        by_id[result.id] = result
        ordered.append(result)
    output.mkdir(parents=True, exist_ok=True)
    payload = {"workflow": workflow.get("name", path.stem), "started": started, "passed": all(item.passed for item in ordered) and len(ordered) == len(workflow["steps"]), "steps": [asdict(item) for item in ordered]}
    (output / "api-pulse-report.json").write_text(json.dumps(payload, indent=2), encoding="utf-8", newline="\n")
    (output / "api-pulse-report.md").write_text(markdown_report(workflow, ordered, started), encoding="utf-8", newline="\n")
    return 0 if payload["passed"] else 1


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workflow", type=Path)
    parser.add_argument("--output", type=Path, default=Path("api-pulse-output"))
    parser.add_argument("--timeout", type=float, default=15.0)
    args = parser.parse_args(argv)
    try:
        return run_workflow(args.workflow, args.output, args.timeout)
    except WorkflowError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
